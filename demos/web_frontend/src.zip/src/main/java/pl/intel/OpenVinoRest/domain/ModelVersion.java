package pl.intel.OpenVinoRest.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import javax.persistence.*;
import java.util.List;
import java.util.UUID;

@Entity
@Getter
@Setter

@AllArgsConstructor
public class ModelVersion {
    @Id
    //@GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonIgnore
    private String id;
    //private Long id;

    @Column(name = "model_version_status")
    @OneToMany(mappedBy = "status")
    private List<ModelVersionStatus> statuses;

    public ModelVersion(List<ModelVersionStatus> versionStatuses) {
        this.id = UUID.randomUUID().toString();
        this.statuses = versionStatuses;

    }
    public ModelVersion() {
        this.id = UUID.randomUUID().toString();

    }
}
