package pl.intel.OpenVinoRest.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import pl.intel.OpenVinoRest.domain.ModelVersion;
import pl.intel.OpenVinoRest.domain.ModelVersionStatus;
import pl.intel.OpenVinoRest.service.ModelVersionService;

import java.util.List;

@RestController
@RequestMapping("/api/model-version")
public class ModelVersionController {
    private ModelVersionService modelVersionService;

    /*@GetMapping
    public ModelVersion getAll() {
        return modelVersionService.getModelStatus();

    }*/

    @GetMapping
    public List<ModelVersionStatus> getAllMS() {
        return modelVersionService.getModelVersionStatus();
    }
}
