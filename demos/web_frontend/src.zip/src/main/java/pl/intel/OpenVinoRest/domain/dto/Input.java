package pl.intel.OpenVinoRest.domain.dto;

import lombok.Data;

@Data
public class Input {
    private String version;

}
