package pl.intel.OpenVinoRest.service;

import org.springframework.stereotype.Service;
import pl.intel.OpenVinoRest.domain.ModelVersion;
import pl.intel.OpenVinoRest.domain.ModelVersionStatus;
import org.springframework.web.client.RestTemplate;
import pl.intel.OpenVinoRest.domain.dto.Input;
import pl.intel.OpenVinoRest.repository.ModelVersionRepository;
import pl.intel.OpenVinoRest.repository.ModelVersionStatusRepository;

import java.util.List;

@Service
public class ModelVersionService {
    final private String restApiPathClear = "http://localhost:9001/v1/models/face-detection";
    final private String restApiPathVersion = "http://localhost:9001/v1/models/face-detection/versions/1";
    RestTemplate restTemplate = new RestTemplate();
    ModelVersionRepository modelVersionRepository;
    ModelVersionStatusRepository modelVersionStatusRepository;

    public ModelVersion getModelStatus(){
        ModelVersion response = restTemplate.getForObject(restApiPathVersion, ModelVersion.class);
        return response;
    }

    public List<ModelVersionStatus> getModelVersionStatus(){
        return modelVersionStatusRepository.findAll();
    }

    public ModelVersion addModelStatus(List<ModelVersionStatus> versionStatuses) {
        ModelVersion modelVersionToAdd = new ModelVersion(versionStatuses);
        modelVersionRepository.save(modelVersionToAdd);
        return  modelVersionToAdd;
    }
}
